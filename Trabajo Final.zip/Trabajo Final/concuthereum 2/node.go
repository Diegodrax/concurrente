package main

import (
	"bufio"
	"crypto/sha1"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"math"
	"net"
	"net/http"
	"os"
	"sort"
	"strconv"
	"time"
)

var localAddr = ""
var RestApiPort = ""

type Columnas struct {
	Temperatura             string
	DiasSintomas            string
	CongestionNasal         string
	ObstruccionRespiratoria string
	Sexo                    string
}

type MarcaDeClase struct {
	Marca string
}

type tx struct {
	Id   string
	Addr string
	Data string
}

type block struct {
	Id     string
	Number int
	Txs    []tx
	Key    int
}

type op struct {
	Type        int // 1 publish tx, 2 mined block
	Transaction tx
	Block       block
}

var peers = []string{
	"localhost:8000",
	"localhost:8001",
	"localhost:8002",
	"localhost:8003",
}

func setUpNode() bool {
	var port string = os.Getenv("PORT")
	RestApiPort = os.Getenv("REST_API_PORT")
	if port == "" || RestApiPort == "" {
		fmt.Println("ERROR : Ports must be declared")
		return false
	} else {
		localAddr = "localhost:" + port
		return true
	}
}

func main() {

	reader := bufio.NewReader(os.Stdin)
	pendingBlock = block{}
	pendingBlock.Number = currentBlock
	if !setUpNode() {
		return
	}
	go BlockchainProtocolServer()
	go RestClientServer()
	//playground()
	time.Sleep(time.Millisecond * 100)

	var operation string
	for {
		fmt.Print("~ ")
		fmt.Scanf("%s\n", &operation)
		switch operation {
		case "publishTx":
			fmt.Print("		Input transaction data : ")
			data, _ := reader.ReadString('\n')
			s := strconv.Itoa(pendingBlock.Number)
			publishTx(tx{calculateSHA1(data + s), localAddr, data}) // falta concepto de nonce
		case "mine":
			mine()
		case "pending":
			pending()
		case "chain":
			PrintChain()
		case "current":
			fmt.Println("		Current Block  Number: " + strconv.Itoa(currentBlock))
		}
	}

}

// Crypto Util

func calculateSHA1(payload string) string {
	h := sha1.New()
	h.Write([]byte(payload))
	sha1_hash := hex.EncodeToString(h.Sum(nil))
	return sha1_hash
}

// Concuthereum PROTOCOL

var currentBlock = 0
var previousBlockId = ""
var blockSize = 2 // Potencia de 2 menos 2 (ID de bloque previo / Seed para Merkle Tree)
var pendingBlock block
var chain []block

func validateMinedBlock(proposedBlock block) {
	var leftParent = calculateSHA1(proposedBlock.Txs[0].Id + proposedBlock.Txs[1].Id)
	var rightParent = calculateSHA1(previousBlockId + strconv.Itoa(proposedBlock.Key)) // Brute Force for Key Calculation
	expectedBlockId := calculateSHA1(leftParent + rightParent)
	if expectedBlockId == proposedBlock.Id {
		chain = append(chain, proposedBlock)
		fmt.Println("		New block mined! Block ID : " + proposedBlock.Id)
		currentBlock++
		previousBlockId = expectedBlockId
		pendingBlock = block{"", currentBlock, []tx{}, -1}
	} else {
		fmt.Println("Invalid Block, chain under attack")
	}
}

func mine() {
	if len(pendingBlock.Txs) != blockSize {
		fmt.Println("\n	! Block doesn't have enough transactions to be mined")
	} else { // TODO : Calculo concurrente de minado
		var leftParent string
		var rightParent string
		var i int = -1
		var newBlockId string

		for { // MINADO
			i++
			leftParent = calculateSHA1(pendingBlock.Txs[0].Id + pendingBlock.Txs[1].Id)
			rightParent = calculateSHA1(previousBlockId + strconv.Itoa(i)) // Brute Force for Key Calculation
			newBlockId = calculateSHA1(leftParent + rightParent)
			if newBlockId[:1] == "0" { // Difficulty
				break
			}
		}

		pendingBlock.Id = newBlockId
		pendingBlock.Key = i
		chain = append(chain, pendingBlock) // Copia?? No sé como funciona la memoria de golang
		fmt.Println("		New block mined! Block ID : " + pendingBlock.Id)
		msg := op{2, tx{}, pendingBlock} // enviamos Key 1 por el momento
		for _, peer := range peers {
			if peer != localAddr {
				send(peer, msg)
			}
		}

		currentBlock++
		previousBlockId = newBlockId
		pendingBlock = block{"", currentBlock, []tx{}, -1}
	}
}

func pending() {
	fmt.Println("\n Pending Block :")
	fmt.Println("		ID : " + pendingBlock.Id)
	fmt.Println("		Number : ", pendingBlock.Number)
	fmt.Println("		TXS : ", pendingBlock.Txs)
}

func PrintChain() {
	fmt.Println("	CHAIN : ", chain)
}

func publishTx(transaction tx) {
	if len(pendingBlock.Txs) < blockSize {
		pendingBlock.Txs = append(pendingBlock.Txs, transaction) // Add Transaction to pending Block
		fmt.Println("\n	+ Transaction with ID : " + transaction.Id + " added to pending block.")
		msg := op{1, transaction, block{}}
		for _, peer := range peers {
			if peer != localAddr {
				send(peer, msg)
			}
		}
	} else {
		return
	}
}

// Rest API Client

func RestClientServer() {
	servidor := http.NewServeMux()
	servidor.HandleFunc("/predict", endpoint)
	servidor.HandleFunc("/kmeans", getKMeans)
	fmt.Println("Rest API server Listening on PORT 5000")
	err := http.ListenAndServe(":"+RestApiPort, servidor)
	log.Fatal(err)
}

func endpoint(w http.ResponseWriter, r *http.Request) {
	var col Columnas
	var mar MarcaDeClase
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "DELETE, POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With")
	w.WriteHeader(http.StatusOK)

	err := json.NewDecoder(r.Body).Decode(&col)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	Temperatura := col.Temperatura
	DiasSintomas := col.DiasSintomas
	CongestionNasal := col.CongestionNasal
	ObstruccionRespiratoria := col.ObstruccionRespiratoria
	Sexo := col.Sexo
	mar.Marca = knn(15, []string{Temperatura, DiasSintomas, CongestionNasal, ObstruccionRespiratoria, Sexo})
	jsonRespuesta, err := json.Marshal(mar)

	data := "{ Temperatura : " + Temperatura + ", DiasSintomas : " + DiasSintomas + ", CongestionNasal : " + CongestionNasal + ", ObstruccionRespiratoria : " + ObstruccionRespiratoria + ", Sexo : " + Sexo + ", Marca : " + mar.Marca + " } "
	s := strconv.Itoa(pendingBlock.Number)
	go publishTx(tx{calculateSHA1(data + s), localAddr, data})

	fmt.Fprintf(w, string(jsonRespuesta))
}

func getKMeans(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "DELETE, POST, GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With")
	w.WriteHeader(http.StatusOK)
	kmeansResult := kmeans(100)

	fmt.Fprintf(w, string("{ \"Centro1\" : \""+kmeansResult[0]+
		"\", \"Centro2\" : \""+kmeansResult[1]+
		"\", \"Centro3\" : \""+kmeansResult[2]+
		"\", \"Centro4\" : \""+kmeansResult[3]+"\" }"))
}

func BlockchainProtocolServer() {
	if ln, err := net.Listen("tcp", localAddr); err != nil {
		log.Panicln("Can't start listener on : ", localAddr)
	} else {
		defer ln.Close()
		fmt.Println("Blockchain Protocol Listeing on : ", localAddr)
		for {
			if conn, err := ln.Accept(); err != nil {
				log.Println("Can't accept : ", conn.RemoteAddr())
			} else {
				go handle(conn)
			}
		}
	}
}

func send(peer string, msg op) {
	if conn, err := net.Dial("tcp", peer); err != nil {
		fmt.Println("	Can't dial : ", peer)
	} else {
		defer conn.Close()
		fmt.Println("	Sending to : ", peer)
		enc := json.NewEncoder(conn)
		enc.Encode(msg)
	}
}

func handle(conn net.Conn) {
	defer conn.Close()
	dec := json.NewDecoder(conn)
	var operation op
	if err := dec.Decode(&operation); err != nil {
		log.Println("Can't decode from", conn.RemoteAddr())
	} else {

		switch operation.Type {
		case 1:
			{ // pulishedTx
				if len(pendingBlock.Txs) < blockSize {
					pendingBlock.Txs = append(pendingBlock.Txs, operation.Transaction)
					fmt.Println("\n	+ Transaction with ID : " + operation.Transaction.Id + " added to pending block.")
				}
			}
		case 2:
			{ // minedBlock
				if operation.Block.Number == currentBlock {
					validateMinedBlock(operation.Block)
				}
			}

		}
	}
}

func playground() {
	var a block = block{}
	var t = tx{"id1", "add1", "Prueba"}
	a.Id = "1"
	a.Txs = append(a.Txs, t)

	fmt.Println(a)
}

// KNN

func calcular_distacia(s1 []string, s2 []string, c chan [2]float64) {
	var distancia float64 = 0.0
	for i := 0; i < 4; i++ {
		elem1, err := strconv.ParseFloat(s1[i], 64)
		if err != nil {
			log.Fatalln(err)
		}
		elem2, err := strconv.ParseFloat(s2[i], 64)
		if err != nil {
			log.Fatalln(err)
		}
		distancia += ((elem1 - elem2) * (elem1 - elem2))
	}
	etiqueta, err := strconv.ParseFloat(s1[5], 64)
	if err != nil {
		log.Fatalln(err)
	}
	c <- [2]float64{math.Sqrt(distancia), etiqueta}
}

func knn(k int, nueva_entrada []string) string {
	nombre_labels := [2]string{"Sano", "Enfermo"}
	cantidad_labels := [2]int{0, 0}
	var valores [][2]float64
	c := make(chan [2]float64)
	csvfile, err := os.Open("dataset.csv")
	if err != nil {
		log.Fatalln("Couldn't open the csv file", err)
	}
	r := csv.NewReader(bufio.NewReader(csvfile))
	fila, err := r.Read()
	_ = fila
	_ = err
	var num_filas int = 0
	sexo_actual, _ := strconv.Atoi(nueva_entrada[4])
	for {
		fila, err := r.Read()
		if err == io.EOF {
			break
		}
		sexo_fila, _ := strconv.Atoi(fila[4])
		if sexo_actual == sexo_fila {
			go calcular_distacia(fila, nueva_entrada, c)
			num_filas += 1
		}
	}
	for i := 0; i < num_filas; i++ {
		valores = append(valores, <-c)
	}
	sort.SliceStable(valores, func(i, j int) bool { return valores[i][0] < valores[j][0] })
	for _, elem := range valores[0:k] {
		cantidad_labels[int(elem[1])] += 1
	}
	var indice_max int = 1
	if cantidad_labels[0] > cantidad_labels[1] {
		indice_max = 0
	}
	return nombre_labels[indice_max]
}

// TODO : Pending Transaction Logic
// TODO : Persistent Chain
// TODO : Wallet Nonce

//NOTA: para llamar al k means usar como parametro el numero 100
//Ejemplo:
//fmt.Println(kmeans(100))
func generar_centroide(uno float64, dos float64, tres float64, cuatro float64) [4]float64 {
	var k [4]float64
	k[0] = uno
	k[1] = dos
	k[2] = tres
	k[3] = cuatro
	return k
}

func distancia_respecto_al_centroide(elemento []float64, centroide [4]float64) float64 {
	var distancia float64 = 0.0
	for i := 0; i < 4; i++ {
		distancia += ((elemento[i] - centroide[i]) * (elemento[i] - centroide[i]))
	}
	return math.Sqrt(distancia)
}

func k_mas_cercano(num_fila int, elemento []float64, centroides [][4]float64, c chan [2]int) {
	var distancia float64 = distancia_respecto_al_centroide(elemento, centroides[0])
	var k_cercano int = 0
	var temp float64
	for i := 1; i < 4; i++ {
		temp = distancia_respecto_al_centroide(elemento, centroides[i])
		if temp < distancia {
			distancia = temp
			k_cercano = i
		}
	}
	c <- [2]int{num_fila, k_cercano}
}

func kmeans_paso_1(dataset [][6]float64, centroides [][4]float64, etiqueta_cercanas []int) {
	c := make(chan [2]int)
	var num_filas int = 0
	for i, elem := range dataset {
		go k_mas_cercano(i, elem[0:4], centroides, c)
		num_filas += 1
	}
	for i := 0; i < num_filas; i++ {
		valor := <-c
		etiqueta_cercanas[valor[0]] = valor[1]
	}
}

func binario_a_entero(digito1 int, digito2 int) int {
	return (digito1 * 2) + digito2
}

func kmeans_paso_2(dataset [][6]float64, centroides [][4]float64, etiqueta_cercanas []int) {
	for i := 0; i < 4; i++ {
		distancias := [4]float64{0.0, 0.0, 0.0, 0.0}
		var num_elementos int = 0
		for j, elem := range etiqueta_cercanas {
			if elem == i {
				if binario_a_entero(int(dataset[j][4]), int(dataset[j][5])) == i {
					distancias[0] += dataset[j][0]
					distancias[1] += dataset[j][1]
					distancias[2] += dataset[j][2]
					distancias[3] += dataset[j][3]
					num_elementos += 1
				}
			}
		}
		var divisor float64 = float64(num_elementos)
		centroides[i][0] = distancias[0] / divisor
		centroides[i][1] = distancias[1] / divisor
		centroides[i][2] = distancias[2] / divisor
		centroides[i][3] = distancias[3] / divisor
	}
}

func kmeans(num_iteraciones int) [4]string {
	var dataset [][6]float64
	var num_filas int = 0
	csvfile, err := os.Open("dataset.csv")
	if err != nil {
		log.Fatalln("Couldn't open the csv file", err)
	}
	r := csv.NewReader(bufio.NewReader(csvfile))
	fila, err := r.Read()
	_ = fila
	_ = err
	for {
		fila, err := r.Read()
		if err == io.EOF {
			break
		}
		item1, _ := strconv.ParseFloat(fila[0], 64)
		item2, _ := strconv.ParseFloat(fila[1], 64)
		item3, _ := strconv.ParseFloat(fila[2], 64)
		item4, _ := strconv.ParseFloat(fila[3], 64)
		item5, _ := strconv.ParseFloat(fila[4], 64)
		item6, _ := strconv.ParseFloat(fila[5], 64)
		dataset = append(dataset, [6]float64{item1, item2, item3, item4, item5, item6})
		num_filas += 1
	}
	centroides := [][4]float64{generar_centroide(37, 5, 1, 0.25), generar_centroide(37, 10, 3, 0.75), generar_centroide(39, 5, 3, 0.25), generar_centroide(39, 10, 1, 0.75)}
	etiqueta_cercanas := make([]int, num_filas)
	for i := 0; i < num_iteraciones; i++ {
		kmeans_paso_1(dataset, centroides, etiqueta_cercanas)
		kmeans_paso_2(dataset, centroides, etiqueta_cercanas)
	}
	resultados := [4]string{"Grupo 1 (Hombres enfermos de covid): Temperatura promedio: " + strconv.FormatFloat(centroides[3][0], 'f', 0, 64) + ", Dias con sintomas promedio: " + strconv.FormatFloat(centroides[3][1], 'f', 0, 64) + ", Congestion nasal promedio: " + strconv.FormatFloat(centroides[3][2], 'f', 0, 64) + ", Obstruccion respiratoria promedio: " + strconv.FormatFloat(centroides[3][3], 'f', 9, 64) + ".",
		"Grupo 2 (Mujeres enfermas de covid): Temperatura promedio: " + strconv.FormatFloat(centroides[1][0], 'f', 0, 64) + ", Dias con sintomas promedio: " + strconv.FormatFloat(centroides[1][1], 'f', 0, 64) + ", Congestion nasal promedio: " + strconv.FormatFloat(centroides[1][2], 'f', 0, 64) + ", Obstruccion respiratoria promedio: " + strconv.FormatFloat(centroides[1][3], 'f', 9, 64) + ".",
		"Grupo 3 (Hombres sanos): Temperatura promedio: " + strconv.FormatFloat(centroides[2][0], 'f', 0, 64) + ", Dias con sintomas promedio: " + strconv.FormatFloat(centroides[2][1], 'f', 0, 64) + ", Congestion nasal promedio: " + strconv.FormatFloat(centroides[2][2], 'f', 0, 64) + ", Obstruccion respiratoria promedio: " + strconv.FormatFloat(centroides[2][3], 'f', 9, 64) + ".",
		"Grupo 4 (Mujeres sanas): Temperatura promedio: " + strconv.FormatFloat(centroides[0][0], 'f', 0, 64) + ", Dias con sintomas promedio: " + strconv.FormatFloat(centroides[0][1], 'f', 0, 64) + ", Congestion nasal promedio: " + strconv.FormatFloat(centroides[0][2], 'f', 0, 64) + ", Obstruccion respiratoria promedio: " + strconv.FormatFloat(centroides[0][3], 'f', 9, 64) + "."}
	return resultados
}
