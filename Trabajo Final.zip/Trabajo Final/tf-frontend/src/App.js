import React from "react";
import { toast } from "react-toastify";
import Button from "@material-ui/core/Button";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Slide from "@material-ui/core/Slide";

import covidNegativo from "./img/covidNegativo.jpeg";
import covidPositivo from "./img/covidPositivo.jpeg";

import "react-toastify/dist/ReactToastify.css";
import "./App.css";

toast.configure();

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

function PredictionForm() {
  const [param1, setParam1] = React.useState("");
  const [param2, setParam2] = React.useState("");
  const [param3, setParam3] = React.useState("");
  const [param4, setParam4] = React.useState("");
  const [param5, setParam5] = React.useState("");
  const [result, setResult] = React.useState("");
  const [sick, setSick] = React.useState();

  React.useEffect(() => {}, [sick]);

  function predict() {
    if (
      param1 == null ||
      param2 == null ||
      param3 == null ||
      param4 == null ||
      param1 == "" ||
      param2 == "" ||
      param3 == "" ||
      param4 == "" ||
      param5 == null ||
      param5 == ""
    ) {
      toast.error("Ingrese los valores de los 5 parametros.");
      return;
    }

    let url = "http://localhost:5000/predict";
    let body = {
      Temperatura: param1,
      DiasSintomas: param2,
      CongestionNasal: param3,
      Sexo: param4,
      ObstruccionRespiratoria: param5,
    };
    console.log(JSON.stringify(body));
    fetch(url, {
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      method: "post",
    })
      .then((a) => a.json())
      .then((data) => {
        console.log("REGRESO ESTO");
        setResult(data.Marca);
        setSick(data.Marca == "Enfermo");
        console.log(data.Marca);
      })
      .catch((err) => {
        toast.error(
          "Error de conexión. Verifique si el backend está levantado en el puerto 5000"
        );
      });
  }
  return (
    <React.Fragment>
      <h1>Predicción de Covid-19</h1>

      {result == "Enfermo" && (
        <React.Fragment>
          <h2 style={{ color: "#0fda6b" }}>POSITIVO A COVID-19</h2>
          <img width="500" src={covidPositivo}></img>
        </React.Fragment>
      )}
      {result == "Sano" && (
        <React.Fragment>
          <h2 style={{ color: "#fb1a30" }}>NEGATIVO A COVID-19</h2>
          <img width="500" src={covidNegativo}></img>
        </React.Fragment>
      )}

      <div>
        <b style={{ margin: "10px" }}>{param1}</b>
        <b style={{ margin: "10px" }}>{param2}</b>
        <b style={{ margin: "10px" }}>{param3}</b>
        <b style={{ margin: "10px" }}>{param4}</b>
        <b style={{ margin: "10px" }}>{param5}</b>
      </div>
      <div>
        <input
          id="param1Input"
          style={{ margin: "5px", borderRadius: "5px", textAlign: "center" }}
          type="text"
          placeholder="Temperatura Corporal"
          onChange={() => {
            setParam1(document.getElementById("param1Input").value);
          }}
        />
        <input
          id="param2Input"
          style={{ margin: "5px", borderRadius: "5px", textAlign: "center" }}
          type="text"
          placeholder="Días con síntomas"
          onChange={() => {
            setParam2(document.getElementById("param2Input").value);
          }}
        />
        <input
          id="param3Input"
          style={{ margin: "5px", borderRadius: "5px", textAlign: "center" }}
          type="text"
          placeholder="Congestión"
          onChange={() => {
            setParam3(document.getElementById("param3Input").value);
          }}
        />
        <input
          id="param4Input"
          style={{ margin: "5px", borderRadius: "5px", textAlign: "center" }}
          type="text"
          placeholder="Sexo"
          onChange={() => {
            setParam4(document.getElementById("param4Input").value);
          }}
        />
        <input
          id="param5Input"
          style={{ margin: "5px", borderRadius: "5px", textAlign: "center" }}
          type="text"
          placeholder="Obstrucción Respiratoria"
          onChange={() => {
            setParam5(document.getElementById("param5Input").value);
          }}
        />
      </div>
      <div>
        <div class="col-6">
          <Button
            style={{ margin: "10px" }}
            variant="contained"
            color="primary"
            onClick={() => {
              predict();
            }}
          >
            Predecir
          </Button>
        </div>
        <div class="col-6">
          <TrainDialog />
        </div>
      </div>
      <br />
      <AlertDialog />
    </React.Fragment>
  );
}

function AlertDialog() {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Button variant="contained" color="secondary" onClick={handleClickOpen}>
        Información del Proyecto
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        TransitionComponent={Transition}
      >
        <DialogTitle id="alert-dialog-title">
          De qué trata el proyecto?
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Este proyecto permite diagnosticar si un paciente tiene covid o no
            basado en nuestro{" "}
            <a href="http://archive.ics.uci.edu/ml/datasets/banknote+authentication">
              Fake Covid Dataset
            </a>
            .
            <br />
            <br />
            Los parámetros de entrada que recibe son:
            <br />
            1. Temperatura corporal (Continuo entre 36 y 40)
            <br />
            2. Días con sintomas (Entero entre 1 y 15)
            <br />
            3. Congestión Nasal (Baja / Media / Alta)
            <br />
            4. Sexo (Femenino / Masculino)
            <br />
            <br />
            5. Obstrucción respiratoria (Continuo entre 0 y 1)
            <br />
            <br />
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary" autoFocus>
            Entendido
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

function TrainDialog() {
  const [open, setOpen] = React.useState(false);
  const [centro1, setCentro1] = React.useState("");
  const [centro2, setCentro2] = React.useState("");
  const [centro3, setCentro3] = React.useState("");
  const [centro4, setCentro4] = React.useState("");
  const [loading, setLoading] = React.useState(true);
  const handleClickOpen = () => {
    setOpen(true);

    let url = "http://localhost:5000/kmeans";

    fetch(url, {
      headers: { "Content-Type": "application/json" },
      method: "get",
    })
      .then((a) => a.json())
      .then((data) => {
        console.log("REGRESO ESTO");
        console.log(data);
        setCentro1(data.Centro1);
        setCentro2(data.Centro2);
        setCentro3(data.Centro3);
        setCentro4(data.Centro4);
        setLoading(false);
      })
      .catch((err) => {
        toast.error(
          "Error de conexión. Verifique si el backend está levantado en el puerto 5000"
        );
      });
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <div>
      <Button variant="contained" color="secondary" onClick={handleClickOpen}>
        Ver Grupos de Dataset
      </Button>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        TransitionComponent={Transition}
      >
        <DialogTitle id="alert-dialog-title">Grupos Identificados</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {loading && <p>loading ... </p>}
            <div style={{ textAlign: "center" }}>
              <p>{centro1}</p>
              <p>{centro2}</p>
              <p>{centro3}</p>
              <p>{centro4}</p>
            </div>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} color="primary" autoFocus>
            Cerrar
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <PredictionForm></PredictionForm>
      </header>
    </div>
  );
}

export default App;
